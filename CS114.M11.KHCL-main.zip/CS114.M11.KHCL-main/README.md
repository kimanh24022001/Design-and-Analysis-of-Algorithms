<p align="center">
  <a href="https://www.uit.edu.vn/" title="Trường Đại học Công nghệ Thông tin" style="border: 5;">
    <img src="https://i.imgur.com/WmMnSRt.png" alt="Trường Đại học Công nghệ Thông tin | University of Information Technology">
  </a>
</p>

<!-- Title -->
<h1 align="center"><b>CS114.M11.KHCL  MACHINE LEARNING</b></h1>

<b>GIẢNG VIÊN HƯỚNG DẪN</b>

PGS.TS Lê Đình Duy

ThS Phạm Nguyễn Trường An

## TABLE OF CONTENTS
* [ Classroom Exercises]
* [ Python programming exercises]
* [ Colab Assignments]
* [ Final Project]



## Nhóm sinh viên thực hiện: NSA

18521144 - Nguyễn Hữu Nghĩa

18521353 - Trần Ngọc Sương

20521072 - Nguyễn Thị Kim Anh
