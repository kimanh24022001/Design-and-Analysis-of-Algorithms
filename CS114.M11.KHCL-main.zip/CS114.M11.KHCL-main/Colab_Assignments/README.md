## LINEAR REGRESSION
 [LINEAR REGRESSION](https://github.com/kimanh24022001/CS114.M11.KHCL/blob/main/Colab_Assignments/NSA_TH1_Linear_Regression.ipynb)
 
## LOGISTIC REGRESSION
 [LOGISTIC REGRESSION](https://github.com/kimanh24022001/CS114.M11.KHCL/blob/main/Colab_Assignments/plot_digits_classification.ipynb)
